function metrics = PR_predMetricsMath_v3(mu_PRS, mu_ABS, sigma_PRS, sigma_ABS, params_est, iModelB)
switch iModelB
    case 1, % multiplicative, additive noise, thresh
        alpha = params_est(1);
        std_add = params_est(2);
        thresh = params_est(3);
    case 2, % additive noise, thresh
        alpha = 0;
        std_add = params_est(1);
        thresh = params_est(2);
    case 3, % multiplicative noise, thresh
        std_add = 0;
        alpha = params_est(1);
        thresh = params_est(2);
end

alpha_PRS = alpha;
alpha_ABS = alpha;
% derive the width of the new IV distribution, with internal noise added
% sigma_IE_PRS = sqrt(1+alpha_PRS^2) * sigma_PRS + std_add;
% sigma_IE_ABS = sqrt(1+alpha_ABS^2) * sigma_ABS + std_add;

sigma_IE_PRS = sqrt((1+alpha_PRS^2) * sigma_PRS + std_add^2);
sigma_IE_ABS = sqrt((1+alpha_ABS^2) * sigma_ABS + std_add^2);


%% predict pHit/pFA/pC3
pHit_math = 1-normcdf(thresh, mu_PRS, sigma_IE_PRS);
pFA_math = 1-normcdf(thresh, mu_ABS, sigma_IE_ABS);
pC_math = (pHit_math+1-pFA_math)/2;

%% predict dprime/criterion
[dprime_math , criterion_math] = SX_sim06_SDT(pHit_math, pFA_math);

%% predict pA by math
PDF_PRS = @(x) normpdf(x, mu_PRS, sigma_IE_PRS);
PDF_ABS = @(x) normpdf(x, mu_ABS, sigma_IE_ABS);
CDF_PRS = normcdf(thresh, mu_PRS, sigma_IE_PRS);
CDF_ABS = normcdf(thresh, mu_ABS, sigma_IE_ABS);

fxn_PRS = @(x) PDF_PRS(x) .* (CDF_PRS.^2 + (1-CDF_PRS).^2);
fxn_ABS = @(x) PDF_ABS(x) .* (CDF_ABS.^2 + (1-CDF_ABS).^2);
pA_PRS_math = integral(fxn_PRS, -inf, inf);
pA_ABS_math = integral(fxn_ABS, -inf, inf);
pA_math = mean([pA_PRS_math, pA_ABS_math]);

%% compile
metrics = [dprime_math, criterion_math, pC_math, pHit_math, pFA_math, pA_math, pA_PRS_math, pA_ABS_math];

