
function pred = PR_pred_v6(iModelB, nBins, params_est, data, c_zscore, flag_plot)

% INPUT:
%   iModelB - Model type for internal noise structure and decision criterion
%   params_est - Estimated parameters for model
%   data - Data structure with fields for internal variables (IV) and responses
%   flag_plot - Flag to enable or disable plotting (unused in current code)

flag_plot = 0;
%% Model setup: Define parameters based on model type (iModelB)
switch iModelB
    case 1 % lapse rate, additive noise, criterion
        Nmul = 0;
        lambda = params_est(1);
        SDadd = params_est(2);
        % criterion = params_est(3);
    case 2 % lapse rate, multiplicative noise, criterion
        SDadd = 0;
        lambda = params_est(1);
        Nmul = params_est(2);
        % criterion = params_est(3);
    case 3 % lapse rate, criterion (no internal noise)
        Nmul = 0;
        SDadd = 0;
        lambda = params_est(1);
        % criterion = params_est(2);
    case 4 % additive noise, criterion
        Nmul = 0;
        SDadd = params_est(1);
        % criterion = params_est(2);
    case 5 % multiplicative noise, criterion
        Nmul = params_est(1);
        SDadd=0;
        % criterion = params_est(2);
end

%% Extract data variables
IV = data.IV; % the integration of stim energy and template for each trial
resp_data = data.resp;
iPair = data.iPair;
iPRS = data.iPRS;
correctness = iPRS==resp_data; % correctness

%% Predict metrics
% Compute predicted standard deviation (sigma) for each trial
sigma_pred = sqrt((IV*Nmul).^2 + SDadd^2);

%% Predict criterion in IV unit
criterion_IV = median(IV)+c_zscore*sigma_pred;
% criterion_IV = c_zscore; % here c_zscore = criterion_true

% Calculate probability of responding "Present" (pYES)
if iModelB<=3
    pYES_pred = lambda/2+(1-lambda)*(1-normcdf(criterion_IV, IV, sigma_pred));
else
    pYES_pred = 1-normcdf(criterion_IV, IV, sigma_pred); % when sigma_pred=0, the normal cdf is a step function, hence pYES_pred are 0/1
end

% convert pYES to pC (accuracy)
pC_pred = nan(size(pYES_pred));
pC_pred(iPRS==1) = pYES_pred(iPRS==1); % for PRS trials (iPRS==1), pC=pYES
pC_pred(iPRS==0) = 1-pYES_pred(iPRS==0); % for ABS trials (iPRS==0), pC=1-pYES

% Compute predicted pA based on predicted pYES
pA_pred = pYES_pred.^2 + (1-pYES_pred).^2;

% Predict dprime
% dprime_pred = norminv(pYES_pred(iPRS==1)) - norminv(pYES_pred(iPRS==0));
% dprime_pred(isinf(dprime_pred)) = NaN; % Handle infinite values from norminv

%% Bin data to calculate predicted and measured pC and pA for each bin
% load binning info
nTrials_allBins = data.nTrials_allBins;
iTrial4Bin = data.iTrial4Bin;

% Verify if paired trials are in the same bin
for iind = 1:length(iTrial4Bin)
    iBin_A = iTrial4Bin(iind);
    iTrialB = find(iPair==iPair(iind));
    iTrialB = iTrialB(2);
    iBin_B = iTrial4Bin(iTrialB);
    if iBin_A ~= iBin_B
        fprintf('Trial%d: Bin%d and %d\n', iind, iBin_A, iBin_B) % confirming that two trials of one pair are in the same bins
    end
end

% Initialize containers for binned values
IV_allBins = nan(nBins, 1);
pYES_pred_allBins = nan(nBins, 1);
pYES_data_allBins = pYES_pred_allBins;
pC_pred_allBins = pYES_pred_allBins;
pC_data_allBins = pYES_pred_allBins;
pA_pred_allBins = pYES_pred_allBins;
pA_data_allBins = pYES_pred_allBins;
% dprime_pred_allBins = pYES_pred_allBins;
% dprime_data_allBins = pYES_pred_allBins;

% Calculate binned values
for iBin = 1:nBins
    indTrial = iTrial4Bin==iBin;
    assert(nTrials_allBins(iBin) == sum(indTrial), 'Error: inconsistent number of trials per bin!')
    IV_allBins(iBin) = mean(IV(indTrial)); % Average IV for bin (should this be weighted by nTrials?)

    pYES_pred_allBins(iBin) = median(pYES_pred(indTrial)); % Predicted accuracy
    pYES_data_allBins(iBin) = mean(resp_data(indTrial)); % Measured accuracy

    % dprime_pred_allBins(iBin) = mean(dprime_pred(indTrial)); % Predicted dprime
    %
    % % calculate measured dprime for each bin using iPRS and correctness
    % correctness_perBin = correctness(indTrial);
    % iPRS_perBin = iPRS(indTrial);
    % pHit = sum(correctness_perBin(iPRS_perBin==1))/sum(iPRS_perBin==1);
    % pFA = sum(correctness_perBin(iPRS_perBin==0))/sum(iPRS_perBin==0);
    % if pHit==1, pHit=1-eps; elseif pHit==0, pHit=eps; end
    % if pFA==1, pFA=1-eps; elseif pFA==0, pFA=eps; end
    % dprime_data_allBins(iBin) = norminv(pHit) - norminv(pFA);

    pC_pred_allBins(iBin) = median(pC_pred(indTrial)); % Predicted accuracy
    pC_data_allBins(iBin) = mean(correctness(indTrial)); % Measured accuracy

    pA_pred_allBins(iBin) = median(pA_pred(indTrial)); % Predicted pA (Measured/data pA is below)

    %------------ Calculate measured pA for each bin ------------
    resp_perBin = resp_data(indTrial);
    iPair_perBin = iPair(indTrial);
    iPair_perBin_unik = unique(iPair_perBin);
    nUnik = length(iPair_perBin_unik);
    respC_perBin = nan(nUnik, 1);
    for iUnik = 1:nUnik
        iTrialAB=find(iPair_perBin==iPair_perBin_unik(iUnik));
        respC_perBin(iUnik) = resp_perBin(iTrialAB(1)) == resp_perBin(iTrialAB(2));
    end
    pA_data_allBins(iBin) = mean(respC_perBin);
    %------------------------------------------
end % iBin

if flag_plot
    %% Plot the distribution of pYES/pC/pA per bin
    figure('Position', [0,0, 2e3, 2e3])
    for iBin = 1:nBins
        indTrial = iTrial4Bin==iBin;

        subplot(nBins,3,(iBin-1)*3+1), hold on
        histogram(pYES_pred(indTrial), 'Normalization','probability');
        xline(median(pYES_pred(indTrial)), 'r-', 'LineWidth', 2);
        xline(mean(pYES_pred(indTrial)), 'g-', 'LineWidth', 2);
        % title(sprintf('Bin %d: pYES_pred distribution', iBin))
        if iBin==nBins, xlabel('pYES');  end
        ylabel('Probability');
        % legend('pYES', 'Median', 'Mean')
        ylim([0, .5])
        xlim([0, 1])

        subplot(nBins,3,(iBin-1)*3+2), hold on
        histogram(pC_pred(indTrial), 'Normalization','probability');
        xline(median(pC_pred(indTrial)), 'r-', 'LineWidth', 2);
        xline(mean(pC_pred(indTrial)), 'g-', 'LineWidth', 2);
        % title(sprintf('Bin %d: pC_pred distribution', iBin))
        if iBin==nBins, xlabel('pC'); end
        ylabel('Probability');
        % legend('pC', 'Median', 'Mean')
        ylim([0, .5])
        xlim([0, 1])

        subplot(nBins,3,(iBin-1)*3+3), hold on
        histogram(pA_pred(indTrial), 'Normalization','probability');
        xline(median(pA_pred(indTrial)), 'r-', 'LineWidth', 2);
        xline(mean(pA_pred(indTrial)), 'g-', 'LineWidth', 2);
        % title(sprintf('Bin %d: pA_pred distribution', iBin))
        if iBin==nBins, xlabel('pA'); end
        ylabel('Probability');
        % legend('pA', 'Median', 'Mean')
        ylim([0, .5])
        xlim([.5, 1])
    end % iBin

    %% Plot trialwise pYES/pC/pA as a fxn of trialwise IV
    figure('Position', [0,0, 2e3, 400])

    subplot(1,3,1), hold on
    plot(IV(iPRS==1), pYES_pred(iPRS==1), 'r.');
    plot(IV(iPRS==0), pYES_pred(iPRS==0), 'b.');
    plot(IV(iPRS==1), resp_data(iPRS==1), 'ro');
    plot(IV(iPRS==0), resp_data(iPRS==0), 'bo');
    xlabel('Trialwise IV')
    ylabel('Probability and binary resp');
    ylim([0, 1])
    title('pYES')

    subplot(1,3,2), hold on
    plot(IV(iPRS==1), pC_pred(iPRS==1), 'r.', 'DisplayName', 'PRS');
    plot(IV(iPRS==0), pC_pred(iPRS==0), 'b.', 'DisplayName', 'ABS');
    plot(IV(iPRS==1), correctness(iPRS==1), 'ro', 'DisplayName', 'PRS');
    plot(IV(iPRS==0), correctness(iPRS==0), 'bo', 'DisplayName', 'ABS');
    xlabel('Trialwise IV')
    ylabel('Probability and binary resp');
    ylim([0, 1])
    title('pC')
    legend('show')

    subplot(1,3,3), hold on
    plot(IV(iPRS==1), pA_pred(iPRS==1), 'r.');
    plot(IV(iPRS==0), pA_pred(iPRS==0), 'b.');
    % plot(IV, respC, 'o');
    xlabel('Trialwise IV')
    ylabel('Probability and binary resp');
    ylim([0, 1])
    title('pA')

    sgtitle('Trialwise metrics as afxn of trialwise IVs')
end
%% Save
pred.criterion_IV = criterion_IV;
pred.metrics.nTrials_allBins = nTrials_allBins;
pred.metrics.IV_allBins = IV_allBins;

% pred.metrics.dprime_pred_allBins = dprime_pred_allBins;
% pred.metrics.dprime_data_allBins = dprime_data_allBins;
% pred.R2_dprime = getR2(dprime_data_allBins, dprime_pred_allBins, nan);
% pred.R2_weighted_dprime = getR2(dprime_data_allBins, dprime_pred_allBins, nTrials_allBins);

pred.metrics.pYES_pred_allBins = pYES_pred_allBins;
pred.metrics.pYES_data_allBins = pYES_data_allBins;
pred.R2_pYES = getR2(pYES_data_allBins, pYES_pred_allBins, nan);
pred.R2_weighted_pYES = getR2(pYES_data_allBins, pYES_pred_allBins, nTrials_allBins);

pred.metrics.pC_pred_allBins = pC_pred_allBins;
pred.metrics.pC_data_allBins = pC_data_allBins;
pred.R2_pC = getR2(pC_data_allBins, pC_pred_allBins, nan);
pred.R2_weighted_pC = getR2(pC_data_allBins, pC_pred_allBins, nTrials_allBins);

pred.metrics.pA_pred_allBins = pA_pred_allBins;
pred.metrics.pA_data_allBins = pA_data_allBins;
pred.R2_pA = getR2(pA_data_allBins, pA_pred_allBins, nan);
pred.R2_weighted_pA = getR2(pA_data_allBins, pA_pred_allBins, nTrials_allBins);

%%
if flag_plot
    sz_scale = 80;
    figure('Position', [0 200 300 800])
    subplot(3,1,1), hold on
    plot(IV_allBins, pYES_pred_allBins, 'k-')
    for iBin=1:nBins, plot(IV_allBins(iBin), pYES_data_allBins(iBin), 'ko', 'MarkerSize', nTrials_allBins(iBin)/sz_scale+5), end
    yline(.5, 'k--');
    ylim([0,1])
    xlabel('Binned IV')
    title('pYES')

    subplot(3,1,2), hold on
    plot(IV_allBins, pC_pred_allBins, 'k-')
    for iBin=1:nBins, plot(IV_allBins(iBin), pC_data_allBins(iBin), 'ko', 'MarkerSize', nTrials_allBins(iBin)/sz_scale+5), end
    yline(.5, 'k--');
    ylim([0,1])
    xlabel('Binned IV')
    title('Accuracy')

    subplot(3,1,3), hold on
    plot(IV_allBins, pA_pred_allBins, 'k-')
    for iBin=1:nBins, plot(IV_allBins(iBin), pA_data_allBins(iBin), 'ko', 'MarkerSize', nTrials_allBins(iBin)/sz_scale+5), end
    ylim([.5,1])
    xlabel('Binned IV')
    title('Resp. consistency')

    sgtitle(sprintf('Nmul=%.2f, SDadd=%.2f', Nmul, SDadd))
    pause, close all
end
end